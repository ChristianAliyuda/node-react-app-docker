export const API_URL = 'http://applicationnode-env.eba-cupmvxnx.us-east-1.elasticbeanstalk.com/'
export default API_URL
