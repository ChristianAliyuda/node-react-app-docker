module.exports = {
    CORS_ORIGIN: 'http://localhost:3000'
}